import { pgTable, text, integer, boolean, timestamp, serial } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  nickname: text("nickname").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  avatarUrl: text("avatar_url"),
  isPremium: boolean("is_premium").default(false),
  isAdmin: boolean("is_admin").default(false),
  activationCode: text("activation_code"),
  isActivated: boolean("is_activated").default(false),
  totalScore: integer("total_score").default(0),
  testsCompleted: integer("tests_completed").default(0),
  studyHours: integer("study_hours").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Subjects table
export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  emoji: text("emoji").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  isSpecialized: boolean("is_specialized").default(false),
  totalQuestions: integer("total_questions").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Questions table
export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  subjectId: integer("subject_id").references(() => subjects.id),
  question: text("question").notNull(),
  options: text("options").notNull(), // JSON string
  correctAnswer: text("correct_answer").notNull(),
  explanation: text("explanation"),
  difficulty: text("difficulty").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Quiz sessions table
export const quizSessions = pgTable("quiz_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  subjectId: integer("subject_id").references(() => subjects.id),
  score: integer("score").default(0),
  totalQuestions: integer("total_questions").notNull(),
  timeSpent: integer("time_spent").default(0),
  answers: text("answers").notNull(), // JSON string
  isCompleted: boolean("is_completed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Study progress table
export const studyProgress = pgTable("study_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  subjectId: integer("subject_id").references(() => subjects.id),
  topic: text("topic").notNull(),
  isCompleted: boolean("is_completed").default(false),
  timeSpent: integer("time_spent").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Study plan content table
export const studyPlanContent = pgTable("study_plan_content", {
  id: serial("id").primaryKey(),
  subjectId: integer("subject_id").references(() => subjects.id),
  topic: text("topic").notNull(),
  content: text("content").notNull(),
  aiModel: text("ai_model").default("gemini"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Schema validators
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const selectUserSchema = createSelectSchema(users);

export const insertSubjectSchema = createInsertSchema(subjects).omit({
  id: true,
  createdAt: true,
});

export const selectSubjectSchema = createSelectSchema(subjects);

export const insertQuestionSchema = createInsertSchema(questions).omit({
  id: true,
  createdAt: true,
});

export const selectQuestionSchema = createSelectSchema(questions);

export const insertQuizSessionSchema = createInsertSchema(quizSessions).omit({
  id: true,
  createdAt: true,
});

export const selectQuizSessionSchema = createSelectSchema(quizSessions);

export const insertStudyProgressSchema = createInsertSchema(studyProgress).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const selectStudyProgressSchema = createSelectSchema(studyProgress);

export const insertStudyPlanContentSchema = createInsertSchema(studyPlanContent).omit({
  id: true,
  createdAt: true,
});

export const selectStudyPlanContentSchema = createSelectSchema(studyPlanContent);

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export type Subject = typeof subjects.$inferSelect;
export type InsertSubject = typeof subjects.$inferInsert;

export type Question = typeof questions.$inferSelect;
export type InsertQuestion = typeof questions.$inferInsert;

export type QuizSession = typeof quizSessions.$inferSelect;
export type InsertQuizSession = typeof quizSessions.$inferInsert;

export type StudyProgress = typeof studyProgress.$inferSelect;
export type InsertStudyProgress = typeof studyProgress.$inferInsert;

export type StudyPlanContent = typeof studyPlanContent.$inferSelect;
export type InsertStudyPlanContent = typeof studyPlanContent.$inferInsert;