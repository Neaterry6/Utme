import { sql } from 'drizzle-orm';
import {
  pgTable,
  varchar,
  text,
  boolean,
  integer,
  timestamp,
  jsonb,
  index,
  serial
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique().notNull(),
  password: varchar("password").notNull(),
  nickname: varchar("nickname").notNull(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  avatarUrl: varchar("avatar_url"),
  isPremium: boolean("is_premium").default(false),
  isAdmin: boolean("is_admin").default(false),
  activationCode: varchar("activation_code"),
  isActivated: boolean("is_activated").default(false),
  totalScore: integer("total_score").default(0),
  testsCompleted: integer("tests_completed").default(0),
  studyHours: integer("study_hours").default(0),
  usageCount: integer("usage_count").default(0), // Track app usage for trial limit
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Subjects table
export const subjects = pgTable("subjects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  emoji: varchar("emoji").notNull(),
  description: text("description"),
  category: varchar("category").default("general"),
  isSpecialized: boolean("is_specialized").default(false),
  totalQuestions: integer("total_questions").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Questions table (for locally stored questions)
export const questions = pgTable("questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  subjectId: varchar("subject_id").notNull(),
  question: text("question").notNull(),
  options: jsonb("options").$type<Array<{ id: string; text: string }>>().notNull(),
  correctAnswer: varchar("correct_answer").notNull(),
  explanation: text("explanation"),
  imageUrl: varchar("image_url"),
  difficulty: varchar("difficulty").default("medium"),
  topic: varchar("topic"),
  year: varchar("year"), // For ALOC API questions
  examType: varchar("exam_type"), // utme, postutme, wassce, neco
  createdAt: timestamp("created_at").defaultNow(),
});

// Quiz sessions table
export const quizSessions = pgTable("quiz_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  subjectId: varchar("subject_id").notNull(),
  subjectName: varchar("subject_name").notNull(),
  questionsData: jsonb("questions_data").$type<Array<{
    id: string;
    question: string;
    options: Array<{ id: string; text: string }>;
    correctAnswer: string;
    userAnswer?: string;
    isCorrect?: boolean;
    explanation?: string;
    imageUrl?: string;
    year?: string;
    examType?: string;
    timeSpent?: number;
  }>>().notNull(),
  userAnswers: jsonb("user_answers").$type<Record<string, string>>().notNull(),
  score: integer("score").default(0),
  correctAnswers: integer("correct_answers").default(0),
  totalQuestions: integer("total_questions").notNull(),
  timeSpent: integer("time_spent").default(0),
  isCompleted: boolean("is_completed").default(false),
  selectedYear: varchar("selected_year"), // User selected year filter
  examType: varchar("exam_type"), // ALOC API exam type
  mode: varchar("mode").default("practice"), // practice or exam
  startedAt: timestamp("started_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Study progress table
export const studyProgress = pgTable("study_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  subjectId: varchar("subject_id").notNull(),
  topic: varchar("topic").notNull(),
  isCompleted: boolean("is_completed").default(false),
  timeSpent: integer("time_spent").default(0),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Study plan content table
export const studyPlanContent = pgTable("study_plan_content", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  subjectId: varchar("subject_id").notNull(),
  topic: varchar("topic").notNull(),
  content: text("content").notNull(),
  aiModel: varchar("ai_model"),
  generatedAt: timestamp("generated_at").defaultNow(),
});

// Competitions table
export const competitions = pgTable("competitions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title").notNull(),
  description: text("description"),
  subjectId: varchar("subject_id").notNull(),
  creatorId: varchar("creator_id").notNull(),
  maxParticipants: integer("max_participants").default(10),
  questionsCount: integer("questions_count").default(20),
  timeLimit: integer("time_limit").default(3600),
  status: varchar("status").default("waiting"),
  startTime: timestamp("start_time"),
  endTime: timestamp("end_time"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Competition participants table
export const competitionParticipants = pgTable("competition_participants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  competitionId: varchar("competition_id").notNull(),
  userId: varchar("user_id").notNull(),
  score: integer("score").default(0),
  timeSpent: integer("time_spent").default(0),
  answers: jsonb("answers").$type<Array<{ questionId: string; selectedAnswer: string; isCorrect: boolean }>>().notNull(),
  rank: integer("rank"),
  joinedAt: timestamp("joined_at").defaultNow(),
});

// Analytics table
export const analytics = pgTable("analytics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  eventType: varchar("event_type").notNull(),
  eventData: jsonb("event_data"),
  sessionId: varchar("session_id"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Offline cache table
export const offlineCache = pgTable("offline_cache", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  subjectId: varchar("subject_id").notNull(),
  contentType: varchar("content_type").notNull(),
  content: jsonb("content").notNull(),
  lastSynced: timestamp("last_synced").defaultNow(),
});

// Explained questions table
export const explainedQuestions = pgTable("explained_questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  subjectId: varchar("subject_id").notNull(),
  questionId: varchar("question_id").notNull(),
  question: text("question").notNull(),
  options: jsonb("options").$type<Array<{ id: string; text: string }>>().notNull(),
  correctAnswer: varchar("correct_answer").notNull(),
  userAnswer: varchar("user_answer").notNull(),
  isCorrect: boolean("is_correct").notNull(),
  explanation: text("explanation").notNull(),
  aiModel: varchar("ai_model").default('gemini'),
  difficulty: varchar("difficulty").default('medium'),
  topic: varchar("topic"),
  explainedAt: timestamp("explained_at").defaultNow(),
}, (table) => [
  index("idx_explained_questions_user_subject").on(table.userId, table.subjectId),
  index("idx_explained_questions_user_question").on(table.userId, table.questionId),
]);

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  quizSessions: many(quizSessions),
  studyProgress: many(studyProgress),
  explainedQuestions: many(explainedQuestions),
  competitionParticipants: many(competitionParticipants),
}));

export const subjectsRelations = relations(subjects, ({ many }) => ({
  questions: many(questions),
  quizSessions: many(quizSessions),
  studyProgress: many(studyProgress),
  studyPlanContent: many(studyPlanContent),
  competitions: many(competitions),
}));

export const questionsRelations = relations(questions, ({ one }) => ({
  subject: one(subjects, {
    fields: [questions.subjectId],
    references: [subjects.id],
  }),
}));

export const quizSessionsRelations = relations(quizSessions, ({ one }) => ({
  user: one(users, {
    fields: [quizSessions.userId],
    references: [users.id],
  }),
  subject: one(subjects, {
    fields: [quizSessions.subjectId],
    references: [subjects.id],
  }),
}));

export const studyProgressRelations = relations(studyProgress, ({ one }) => ({
  user: one(users, {
    fields: [studyProgress.userId],
    references: [users.id],
  }),
  subject: one(subjects, {
    fields: [studyProgress.subjectId],
    references: [subjects.id],
  }),
}));

export const explainedQuestionsRelations = relations(explainedQuestions, ({ one }) => ({
  user: one(users, {
    fields: [explainedQuestions.userId],
    references: [users.id],
  }),
  subject: one(subjects, {
    fields: [explainedQuestions.subjectId],
    references: [subjects.id],
  }),
}));

// Zod validation schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSubjectSchema = createInsertSchema(subjects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertQuestionSchema = createInsertSchema(questions).omit({
  id: true,
  createdAt: true,
});

export const insertQuizSessionSchema = createInsertSchema(quizSessions).omit({
  id: true,
  startedAt: true,
});

export const insertStudyProgressSchema = createInsertSchema(studyProgress).omit({
  id: true,
  createdAt: true,
});

export const insertStudyPlanContentSchema = createInsertSchema(studyPlanContent).omit({
  id: true,
  generatedAt: true,
});

export const insertCompetitionSchema = createInsertSchema(competitions).omit({
  id: true,
  createdAt: true,
});

export const insertCompetitionParticipantSchema = createInsertSchema(competitionParticipants).omit({
  id: true,
  joinedAt: true,
});

export const insertAnalyticsSchema = createInsertSchema(analytics).omit({
  id: true,
  timestamp: true,
});

export const insertOfflineCacheSchema = createInsertSchema(offlineCache).omit({
  id: true,
  lastSynced: true,
});

export const insertExplainedQuestionSchema = createInsertSchema(explainedQuestions).omit({
  id: true,
  explainedAt: true,
});

// Additional schemas for the admin account
export const upsertUserSchema = createInsertSchema(users).extend({
  id: z.string().optional(),
}).omit({
  createdAt: true,
  updatedAt: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type Subject = typeof subjects.$inferSelect;
export type InsertSubject = z.infer<typeof insertSubjectSchema>;
export type Question = typeof questions.$inferSelect;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;
export type QuizSession = typeof quizSessions.$inferSelect;
export type InsertQuizSession = z.infer<typeof insertQuizSessionSchema>;
export type StudyProgress = typeof studyProgress.$inferSelect;
export type InsertStudyProgress = z.infer<typeof insertStudyProgressSchema>;
export type StudyPlanContent = typeof studyPlanContent.$inferSelect;
export type InsertStudyPlanContent = z.infer<typeof insertStudyPlanContentSchema>;
export type Competition = typeof competitions.$inferSelect;
export type InsertCompetition = z.infer<typeof insertCompetitionSchema>;
export type CompetitionParticipant = typeof competitionParticipants.$inferSelect;
export type InsertCompetitionParticipant = z.infer<typeof insertCompetitionParticipantSchema>;
export type Analytics = typeof analytics.$inferSelect;
export type InsertAnalytics = z.infer<typeof insertAnalyticsSchema>;
export type OfflineCache = typeof offlineCache.$inferSelect;
export type InsertOfflineCache = z.infer<typeof insertOfflineCacheSchema>;
export type ExplainedQuestion = typeof explainedQuestions.$inferSelect;
export type InsertExplainedQuestion = z.infer<typeof insertExplainedQuestionSchema>;