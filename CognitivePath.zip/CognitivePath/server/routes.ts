import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import bcrypt from "bcrypt";
import { storage } from "./storage";
import { aiService } from "./services/aiService";
import { wikiService } from "./services/wikiService";
import { insertUserSchema, insertQuizSessionSchema } from "@shared/schema";

// Valid unlock codes
const VALID_UNLOCK_CODES = ['0814880', '0901918', '0803989'];

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // In-memory user storage for testing (temporary until MongoDB is fixed)
  const tempUsers = new Map();

  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { firstName, lastName, email, nickname, password } = req.body;
      
      if (!firstName || !lastName || !email || !nickname || !password) {
        return res.status(400).json({ message: "All fields are required" });
      }

      // Check if email already exists in temp storage
      if (tempUsers.has(email)) {
        return res.status(400).json({ message: "Email already registered" });
      }

      // Simple password hashing (for testing - normally use bcrypt)
      const hashedPassword = password + '_hashed_' + email;

      // Create user object
      const newUser = {
        _id: `user_${Date.now()}`,
        firstName, 
        lastName, 
        email, 
        nickname, 
        password: hashedPassword,
        isAdmin: false,
        isPremium: false,
        isActivated: true, // Auto-activate for testing
        totalScore: 0,
        testsCompleted: 0,
        studyHours: 0,
        createdAt: new Date(),
        updatedAt: new Date()
      };

      // Store in temporary storage
      tempUsers.set(email, newUser);
      
      console.log('User registered:', email);
      
      // Remove password from response
      const { password: _, ...userResponse } = newUser;
      res.json(userResponse);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  // Login route
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }

      // TEMPORARY: Allow admin login with hardcoded credentials for testing
      if (email === "admin@cbtplatform.com" && password === "admin123") {
        const adminUser = {
          _id: "admin123",
          email: "admin@cbtplatform.com",
          nickname: "admin", 
          firstName: "Admin",
          lastName: "User",
          isAdmin: true,
          isPremium: true,
          isActivated: true,
          totalScore: 0,
          testsCompleted: 0,
          studyHours: 0,
          createdAt: new Date(),
          updatedAt: new Date()
        };
        
        // Skip session for now - just return user data
        
        return res.json(adminUser);
      }

      // Check temporary user storage first
      let user = tempUsers.get(email);
      
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // Simple password verification for testing
      const expectedHash = password + '_hashed_' + email;
      if (user.password !== expectedHash) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // Skip session for now - just return user data

      // Remove password from response
      const { password: _, ...userResponse } = user;
      res.json(userResponse);
    } catch (error) {
      console.error("Error during login:", error);
      res.status(500).json({ message: "Failed to login" });
    }
  });

  // Activation route
  app.post("/api/auth/activate", async (req, res) => {
    try {
      const { userId, activationCode } = req.body;
      
      if (!userId || !activationCode) {
        return res.status(400).json({ message: "User ID and activation code are required" });
      }

      // Check if the code matches the valid unlock codes
      if (!VALID_UNLOCK_CODES.includes(activationCode)) {
        return res.status(400).json({ message: "Invalid activation code. Please message admin on WhatsApp to get a valid unlock code." });
      }

      // Check if user exists in temporary storage first 
      let user = tempUsers.get(userId) || Array.from(tempUsers.values()).find(u => u._id === userId);
      
      if (!user) {
        // Try database storage
        try {
          user = await storage.getUser(userId);
        } catch (error) {
          console.log("User not found in database storage");
        }
      }
      
      if (!user) {
        return res.status(404).json({ message: "User not found. Please make sure you're logged in." });
      }

      // Update user to premium status
      if (user._id) {
        // Update temporary user
        const updatedUser = { 
          ...user, 
          isPremium: true, 
          isActivated: true, 
          activationCode: activationCode,
          updatedAt: new Date()
        };
        tempUsers.set(user.email, updatedUser);
        tempUsers.set(user._id, updatedUser);
        
        const { password: _, ...userResponse } = updatedUser;
        res.json({ 
          message: "Account activated successfully! You now have unlimited access to all features.", 
          user: userResponse 
        });
      } else {
        // Update database user
        const updatedUser = await storage.updateUser(user.id, {
          isPremium: true,
          isActivated: true,
          activationCode: activationCode,
          updatedAt: new Date()
        });

        res.json({ 
          message: "Account activated successfully! You now have unlimited access to all features.", 
          user: updatedUser 
        });
      }
    } catch (error) {
      console.error("Error during activation:", error);
      res.status(500).json({ message: "Failed to activate account" });
    }
  });



  // Legacy nickname registration (keeping for backward compatibility)
  app.post("/api/auth/register-nickname", upload.single('avatar'), async (req, res) => {
    try {
      const { nickname } = req.body;
      
      if (!nickname) {
        return res.status(400).json({ message: "Nickname is required" });
      }

      // Check if nickname already exists
      const existingUser = await storage.getUserByNickname(nickname);
      if (existingUser) {
        return res.status(400).json({ message: "Nickname already taken" });
      }

      let avatarUrl = null;
      if (req.file) {
        // In production, upload to cloud storage (AWS S3, Cloudinary, etc.)
        // For now, we'll store as base64 - this is not recommended for production
        avatarUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
      }

      const userData = { 
        nickname, 
        avatarUrl,
        email: `${nickname}@temp.com`, // Temporary email for legacy users
        password: 'legacy', // Legacy users don't have passwords
        firstName: nickname,
        lastName: '',
        isAdmin: false,
        isPremium: false,
        isActivated: true,
        totalScore: 0,
        testsCompleted: 0,
        studyHours: 0
      };
      const user = await storage.createUser(userData);
      
      res.json(user);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Subject routes
  app.get("/api/subjects", async (req, res) => {
    try {
      const subjects = await storage.getAllSubjects();
      res.json(subjects);
    } catch (error) {
      console.error("Error fetching subjects:", error);
      res.status(500).json({ message: "Failed to fetch subjects" });
    }
  });

  // Initialize subjects if they don't exist
  app.post("/api/subjects/init", async (req, res) => {
    try {
      const existingSubjects = await storage.getAllSubjects();
      if (existingSubjects.length > 0) {
        return res.json({ message: "Subjects already initialized" });
      }

      const defaultSubjects = [
        { name: "English", emoji: "📚", description: "English Language and Literature", category: "Core", isSpecialized: false, totalQuestions: 0 },
        { name: "Mathematics", emoji: "🧮", description: "Mathematical concepts and problem solving", category: "Core", isSpecialized: false, totalQuestions: 0 },
        { name: "Biology", emoji: "🧬", description: "Biological sciences and life processes", category: "Science", isSpecialized: false, totalQuestions: 0 },
        { name: "Physics", emoji: "⚡", description: "Physical sciences and natural phenomena", category: "Science", isSpecialized: false, totalQuestions: 0 },
        { name: "Chemistry", emoji: "🧪", description: "Chemical reactions and molecular structures", category: "Science", isSpecialized: false, totalQuestions: 0 },
        { name: "Economics", emoji: "💰", description: "Economic principles and market analysis", category: "Social Science", isSpecialized: false, totalQuestions: 0 },
        { name: "Government", emoji: "🏛️", description: "Political science and governance", category: "Social Science", isSpecialized: false, totalQuestions: 0 },
        { name: "Literature", emoji: "📖", description: "Literary works and analysis", category: "Arts", isSpecialized: false, totalQuestions: 0 },
      ];

      const createdSubjects = [];
      for (const subject of defaultSubjects) {
        const created = await storage.createSubject(subject);
        createdSubjects.push(created);
      }

      res.json(createdSubjects);
    } catch (error) {
      console.error("Error initializing subjects:", error);
      res.status(500).json({ message: "Failed to initialize subjects" });
    }
  });

  // User usage tracking for premium limits
  app.post("/api/users/:id/usage", async (req, res) => {
    try {
      const userId = req.params.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Only increment for non-premium users
      if (!user.isPremium) {
        const newUsageCount = (user.usageCount || 0) + 1;
        await storage.updateUser(userId, { usageCount: newUsageCount });
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Error updating usage:", error);
      res.status(500).json({ message: "Failed to update usage" });
    }
  });

  // Quiz routes - Enhanced with JAMB API integration
  app.get("/api/quiz/questions/:subjectId", async (req, res) => {
    try {
      const { subjectId } = req.params;
      const limit = parseInt(req.query.limit as string) || 20;
      const year = req.query.year as string;
      const type = req.query.type as 'utme' | 'wassce' | 'neco' | 'post-utme';
      
      // Get the subject name from storage  
      let subjectName = subjectId;
      try {
        const subject = await storage.getSubject(subjectId);
        if (subject) {
          subjectName = subject.name.toLowerCase();
        }
      } catch (error) {
        console.log("Subject not found in storage, using subjectId as subject name");
      }

      // Import ALOC API service
      const { jambApiService, getFallbackQuestions } = await import('./services/jambApiService');

      // Try to fetch fresh questions from ALOC API first
      try {
        console.log(`Fetching ${limit} questions for ${subjectName}, year: ${year}, type: ${type}`);
        const jambQuestions = await jambApiService.fetchQuestions(subjectName, {
          limit,
          year,
          type: type || 'utme',
          accessToken: 'QB-139d5195a490b3c12794'
        });

        if (jambQuestions.length > 0) {
          // Convert JAMB questions to our format
          const formattedQuestions = jambQuestions.map((q, index) => 
            jambApiService.formatQuestion(q, index)
          );
          
          console.log(`Successfully fetched ${formattedQuestions.length} unique questions from ALOC API for ${subjectId}`);
          return res.json(formattedQuestions);
        }
      } catch (apiError) {
        console.error("ALOC API error:", apiError);
        // Continue to fallback to local storage
      }

      // Fallback to local storage questions
      const localQuestions = await storage.getQuestionsBySubject(subjectId, limit);
      if (localQuestions.length > 0) {
        console.log(`Using ${localQuestions.length} local questions for ${subjectName}`);
        return res.json(localQuestions);
      }

      // If no questions found anywhere, create some sample questions as immediate fix
      console.log(`No questions found for ${subjectId}, generating sample questions`);
      const sampleQuestions = getFallbackQuestions(subjectId, limit);
      res.json(sampleQuestions);
      
    } catch (error) {
      console.error("Error fetching questions:", error);
      res.status(500).json({ 
        message: "Failed to fetch questions",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get available years for ALOC API
  app.get("/api/quiz/available-years", async (req, res) => {
    try {
      const { jambApiService } = await import('./services/jambApiService');
      const years = jambApiService.getAvailableYears();
      res.json({ years });
    } catch (error) {
      console.error("Error getting available years:", error);
      res.status(500).json({ message: "Failed to get available years" });
    }
  });

  // Get available exam types for ALOC API
  app.get("/api/quiz/available-exam-types", async (req, res) => {
    try {
      const { jambApiService } = await import('./services/jambApiService');
      const examTypes = jambApiService.getAvailableExamTypes();
      res.json({ examTypes });
    } catch (error) {
      console.error("Error getting available exam types:", error);
      res.status(500).json({ message: "Failed to get available exam types" });
    }
  });

  // Get available years for ALOC API
  app.get("/api/quiz/available-years", async (req, res) => {
    try {
      const { jambApiService } = await import('./services/jambApiService');
      const years = jambApiService.getAvailableYears();
      res.json({ years });
    } catch (error) {
      console.error("Error getting available years:", error);
      res.status(500).json({ message: "Failed to get available years" });
    }
  });

  // Enhanced quiz session creation with better data storage
  app.post("/api/quiz/create-session", async (req, res) => {
    try {
      const { userId, subjectId, subjectName, questions, selectedYear, examType, mode } = req.body;
      
      if (!userId || !subjectId || !questions || !Array.isArray(questions)) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      // Let the database auto-generate the ID and startedAt timestamp
      const sessionData = {
        userId,
        subjectId,
        subjectName: subjectName || 'Unknown Subject',
        questionsData: questions,
        userAnswers: {},
        score: 0,
        correctAnswers: 0,
        totalQuestions: questions.length,
        timeSpent: 0,
        isCompleted: false,
        selectedYear: selectedYear || null,
        examType: examType || 'utme',
        mode: mode || 'practice',
      };

      const session = await storage.createQuizSession(sessionData);
      res.json(session);
      
    } catch (error) {
      console.error("Error creating quiz session:", error);
      res.status(500).json({ message: "Failed to create quiz session" });
    }
  });

  // Enhanced quiz submission endpoint
  app.post("/api/quiz/submit", async (req, res) => {
    try {
      const { sessionId, userAnswers, timeSpent, questionsData } = req.body;
      
      if (!sessionId || !userAnswers) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      // Get the quiz session
      const session = await storage.getQuizSession(sessionId);
      if (!session) {
        return res.status(404).json({ message: "Quiz session not found" });
      }

      // Calculate score based on questions data
      let correctAnswers = 0;
      const questions = questionsData || session.questionsData || [];
      const totalQuestions = questions.length;
      
      // Check each answer
      questions.forEach((question: any) => {
        const userAnswer = userAnswers[question.id];
        if (userAnswer === question.correctAnswer) {
          correctAnswers++;
        }
      });

      const score = totalQuestions > 0 ? Math.round((correctAnswers / totalQuestions) * 100) : 0;

      // Update session with results
      const updatedSession = await storage.updateQuizSession(sessionId, {
        userAnswers,
        questionsData: questions, // Store questions data for review
        timeSpent: timeSpent || 0,
        isCompleted: true,
        completedAt: new Date(),
        score,
        correctAnswers,
      });

      // Update user stats
      try {
        const user = await storage.getUser(session.userId);
        if (user) {
          await storage.updateUser(session.userId, {
            totalScore: (user.totalScore || 0) + correctAnswers,
            testsCompleted: (user.testsCompleted || 0) + 1,
            updatedAt: new Date()
          });
        }
      } catch (userError) {
        console.error("Error updating user stats:", userError);
      }

      res.json({
        sessionId,
        score,
        correctAnswers,
        totalQuestions,
        timeSpent: timeSpent || 0,
        isCompleted: true,
        questions,
        userAnswers
      });
      
    } catch (error) {
      console.error("Error submitting quiz:", error);
      res.status(500).json({ message: "Failed to submit quiz" });
    }
  });

  // AI explanation route - Fixed parameter handling
  app.post("/api/quiz/explanation", async (req, res) => {
    try {
      const { questionId, question, correctAnswer, userAnswer, options, subject } = req.body;
      
      if (!question || !correctAnswer || !subject) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      // Import HTML-based API service for AI explanations
      const { htmlBasedApiService } = await import('./services/htmlBasedApiService');
      
      // Check if explanation already exists for this user and question
      const { userId } = req.body;
      if (userId && questionId) {
        const existingExplanation = await storage.getExplainedQuestion(userId, questionId);
        if (existingExplanation) {
          return res.json({
            explanation: existingExplanation.explanation,
            provider: existingExplanation.aiModel,
            cached: true,
            explainedAt: existingExplanation.explainedAt
          });
        }
      }

      // Generate explanation using enhanced AI system (matching HTML implementation)
      const explanation = await htmlBasedApiService.generateGeminiExplanation(
        question,
        correctAnswer,
        userAnswer || 'No answer provided',
        options,
        subject
      );

      // Store the explanation if user and question info provided
      if (userId && questionId && options) {
        try {
          await storage.createExplainedQuestion({
            userId,
            subjectId: subject,
            questionId,
            question,
            options: Array.isArray(options) ? options : [],
            correctAnswer,
            userAnswer: userAnswer || 'No answer provided',
            isCorrect: userAnswer === correctAnswer,
            explanation,
            aiModel: 'gemini',
            difficulty: 'medium'
          });
        } catch (storageError) {
          console.error("Failed to store explanation:", storageError);
        }
      }
      
      res.json({
        explanation,
        provider: 'gemini',
        enhanced: true,
        cached: false
      });
    } catch (error) {
      console.error("Error generating AI explanation:", error);
      res.status(500).json({ 
        message: "Failed to generate explanation",
        explanation: "An error occurred while generating the explanation. Please try again.",
        provider: 'error',
        enhanced: false
      });
    }
  });

  app.post("/api/quiz/start", async (req, res) => {
    try {
      const sessionData = insertQuizSessionSchema.parse(req.body);
      const session = await storage.createQuizSession(sessionData);
      res.json(session);
    } catch (error) {
      console.error("Error starting quiz:", error);
      res.status(500).json({ message: "Failed to start quiz" });
    }
  });

  app.put("/api/quiz/session/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const updates = req.body;
      
      // Enhanced completion tracking with full question storage
      if (updates.isCompleted && updates.questions) {
        // Store completed questions with full details for later review
        const enhancedUpdates = {
          ...updates,
          questions: updates.questions.map((q: any) => ({
            id: q.id,
            question: q.question,
            options: q.options,
            correctAnswer: q.correctAnswer,
            userAnswer: q.userAnswer,
            isCorrect: q.userAnswer === q.correctAnswer,
            explanation: q.explanation || null,
            timeSpent: q.timeSpent || 0
          }))
        };
        
        const session = await storage.updateQuizSession(sessionId, enhancedUpdates);
        res.json(session);
      } else {
        const session = await storage.updateQuizSession(sessionId, updates);
        res.json(session);
      }
    } catch (error) {
      console.error("Error updating quiz session:", error);
      res.status(500).json({ message: "Failed to update quiz session" });
    }
  });

  app.get("/api/quiz/sessions/:userId", async (req, res) => {
    try {
      const sessions = await storage.getUserQuizSessions(req.params.userId);
      res.json(sessions);
    } catch (error) {
      console.error("Error fetching quiz sessions:", error);
      res.status(500).json({ message: "Failed to fetch quiz sessions" });
    }
  });

  // Enhanced explained questions routes
  app.get("/api/explained-questions/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const { subjectId, limit } = req.query;
      
      const explanations = await storage.getExplainedQuestionsByUser(
        userId,
        subjectId as string,
        parseInt(limit as string) || 20
      );
      
      res.json(explanations);
    } catch (error) {
      console.error("Error fetching explained questions:", error);
      res.status(500).json({ message: "Failed to fetch explained questions" });
    }
  });

  app.get("/api/explained-questions/:userId/:subjectId", async (req, res) => {
    try {
      const { userId, subjectId } = req.params;
      const { limit } = req.query;
      
      const explanations = await storage.getExplainedQuestionsBySubject(
        userId,
        subjectId,
        parseInt(limit as string) || 20
      );
      
      res.json(explanations);
    } catch (error) {
      console.error("Error fetching subject explained questions:", error);
      res.status(500).json({ message: "Failed to fetch subject explained questions" });
    }
  });

  // Generate quiz from explained questions
  app.get("/api/quiz/from-explained/:userId/:subjectId", async (req, res) => {
    try {
      const { userId, subjectId } = req.params;
      const { limit, difficulty } = req.query;
      
      const explanations = await storage.getExplainedQuestionsBySubject(
        userId,
        subjectId,
        parseInt(limit as string) || 10
      );
      
      // Convert explained questions to quiz format
      const quizQuestions = explanations.map(exp => ({
        id: exp.questionId,
        question: exp.question,
        options: exp.options,
        correctAnswer: exp.correctAnswer,
        difficulty: exp.difficulty,
        explanation: exp.explanation,
        source: 'explained-questions'
      }));
      
      // Shuffle questions for varied quiz experience
      const shuffledQuestions = quizQuestions.sort(() => Math.random() - 0.5);
      
      res.json(shuffledQuestions);
    } catch (error) {
      console.error("Error generating quiz from explained questions:", error);
      res.status(500).json({ message: "Failed to generate quiz from explained questions" });
    }
  });

  // Delete explained question
  app.delete("/api/explained-questions/:id", async (req, res) => {
    try {
      const success = await storage.deleteExplainedQuestion(req.params.id);
      res.json({ success });
    } catch (error) {
      console.error("Error deleting explained question:", error);
      res.status(500).json({ message: "Failed to delete explained question" });
    }
  });

  // Legacy AI explanation route (forwards to enhanced explanation handler)
  app.post("/api/ai/explain", async (req, res) => {
    try {
      const { questionId, question, correctAnswer, userAnswer, aiModel } = req.body;
      
      if (!question || !correctAnswer) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      // Forward to the enhanced explanation handler
      const response = await fetch(`${req.protocol}://${req.get('host')}/api/quiz/explanation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          questionId,
          question,
          correctAnswer,
          userAnswer: userAnswer || 'No answer provided',
          subject: req.body.subject || 'general',
          userId: req.body.userId
        })
      });

      const data = await response.json();
      
      if (response.ok) {
        res.json({
          explanation: data.explanation,
          provider: data.provider,
          cached: data.cached
        });
      } else {
        res.status(response.status).json(data);
      }
    } catch (error) {
      console.error("Error in legacy AI explanation route:", error);
      res.status(500).json({ 
        message: "Failed to generate explanation",
        explanation: "An error occurred while generating the explanation. Please try again."
      });
    }
  });

  // Study plan routes
  app.get("/api/study-plan/:subjectId/:topic", async (req, res) => {
    try {
      const { subjectId, topic } = req.params;
      const { aiModel = 'gemini' } = req.query;
      
      // Try to get existing content first
      let content = await storage.getStudyPlanContent(subjectId, topic);
      
      if (!content) {
        // Generate new content using AI
        const subject = await storage.getSubject(subjectId);
        if (!subject) {
          return res.status(404).json({ message: "Subject not found" });
        }

        const generatedContent = await aiService.generateStudyPlan(
          subject.name,
          topic,
          aiModel as string
        );

        content = await storage.saveStudyPlanContent({
          subjectId,
          topic,
          content: generatedContent,
          aiModel: aiModel as string,
        });
      }
      
      res.json(content);
    } catch (error) {
      console.error("Error fetching study plan:", error);
      res.status(500).json({ message: "Failed to fetch study plan" });
    }
  });

  app.post("/api/study-plan/regenerate", async (req, res) => {
    try {
      const { subjectId, topic, aiModel = 'gemini' } = req.body;
      
      const subject = await storage.getSubject(subjectId);
      if (!subject) {
        return res.status(404).json({ message: "Subject not found" });
      }

      const generatedContent = await aiService.generateStudyPlan(
        subject.name,
        topic,
        aiModel
      );

      const content = await storage.saveStudyPlanContent({
        subjectId,
        topic,
        content: generatedContent,
        aiModel,
      });
      
      res.json(content);
    } catch (error) {
      console.error("Error regenerating study plan:", error);
      res.status(500).json({ message: "Failed to regenerate study plan" });
    }
  });

  // Study progress routes
  app.get("/api/study-progress/:userId/:subjectId", async (req, res) => {
    try {
      const { userId, subjectId } = req.params;
      const progress = await storage.getStudyProgress(userId, subjectId);
      res.json(progress);
    } catch (error) {
      console.error("Error fetching study progress:", error);
      res.status(500).json({ message: "Failed to fetch study progress" });
    }
  });

  app.post("/api/study-progress/mark-studied", async (req, res) => {
    try {
      const { userId, subjectId, topic } = req.body;
      const progress = await storage.markTopicAsStudied(userId, subjectId, topic);
      res.json(progress);
    } catch (error) {
      console.error("Error marking topic as studied:", error);
      res.status(500).json({ message: "Failed to mark topic as studied" });
    }
  });

  // AI explanation routes
  app.post("/api/ai/explain", async (req, res) => {
    try {
      const { question, correctAnswer, userAnswer, aiModel = 'gemini' } = req.body;
      
      const explanation = await aiService.generateExplanation(
        question,
        correctAnswer,
        userAnswer,
        aiModel
      );
      
      res.json({ explanation });
    } catch (error) {
      console.error("Error generating explanation:", error);
      res.status(500).json({ message: "Failed to generate explanation" });
    }
  });

  // Wikipedia search routes
  app.get("/api/wikipedia/search", async (req, res) => {
    try {
      const { query } = req.query;
      if (!query) {
        return res.status(400).json({ message: "Query parameter is required" });
      }
      
      const results = await wikiService.search(query as string);
      res.json(results);
    } catch (error) {
      console.error("Error searching Wikipedia:", error);
      res.status(500).json({ message: "Failed to search Wikipedia" });
    }
  });

  // Leaderboard routes
  app.get("/api/leaderboard", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const leaderboard = await storage.getLeaderboard(limit);
      res.json(leaderboard);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      res.status(500).json({ message: "Failed to fetch leaderboard" });
    }
  });

  // Admin routes - TEMPORARY with mock data for testing
  app.get("/api/admin/stats", async (req, res) => {
    try {
      // Temporary mock stats for admin testing
      const mockStats = {
        totalUsers: 25,
        totalQuestions: 150,
        totalSessions: 75,
        activeUsers: 18
      };
      res.json(mockStats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin stats" });
    }
  });

  app.get("/api/admin/users", async (req, res) => {
    try {
      // Temporary mock users for admin testing
      const mockUsers = [
        {
          _id: "admin123",
          email: "admin@cbtplatform.com",
          nickname: "admin",
          firstName: "Admin",
          lastName: "User",
          isAdmin: true,
          isPremium: true,
          isActivated: true,
          totalScore: 0,
          testsCompleted: 0,
          studyHours: 0,
          createdAt: new Date()
        },
        {
          _id: "user1",
          email: "student@example.com",
          nickname: "student1",
          firstName: "John",
          lastName: "Doe",
          isAdmin: false,
          isPremium: true,
          isActivated: true,
          totalScore: 85,
          testsCompleted: 5,
          studyHours: 12,
          createdAt: new Date()
        }
      ];
      res.json(mockUsers);
    } catch (error) {
      console.error("Error fetching admin users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get("/api/admin/questions", async (req, res) => {
    try {
      // Temporary mock questions for admin testing
      const mockQuestions = [
        {
          _id: "q1",
          question: "What is the capital of Nigeria?",
          options: ["Lagos", "Abuja", "Kano", "Port Harcourt"],
          correctAnswer: "Abuja",
          subject: "Geography",
          difficulty: "easy",
          createdAt: new Date()
        },
        {
          _id: "q2", 
          question: "Which organ is responsible for pumping blood?",
          options: ["Brain", "Heart", "Liver", "Kidney"],
          correctAnswer: "Heart",
          subject: "Biology",
          difficulty: "easy",
          createdAt: new Date()
        }
      ];
      res.json(mockQuestions);
    } catch (error) {
      console.error("Error fetching admin questions:", error);
      res.status(500).json({ message: "Failed to fetch questions" });
    }
  });

  // Create admin account endpoint - TEMPORARY simplified version
  app.post("/api/admin/create-admin", async (req, res) => {
    try {
      // For demonstration purposes, we'll just return success
      // In a real app, this would create the admin user in the database
      const adminResponse = {
        _id: "admin123",
        email: "admin@cbtplatform.com", 
        nickname: "admin",
        firstName: "Admin",
        lastName: "User",
        isAdmin: true,
        isPremium: true,
        isActivated: true
      };
      
      res.json({ 
        message: "Admin account ready - use email: admin@cbtplatform.com, password: admin123", 
        admin: adminResponse 
      });
    } catch (error) {
      console.error("Error creating admin:", error);
      res.status(500).json({ message: "Failed to create admin account" });
    }
  });

  app.post("/api/admin/subjects", async (req, res) => {
    try {
      const subject = await storage.createSubject(req.body);
      res.json(subject);
    } catch (error) {
      console.error("Error creating subject:", error);
      res.status(500).json({ message: "Failed to create subject" });
    }
  });

  app.post("/api/admin/questions", async (req, res) => {
    try {
      const question = await storage.createQuestion(req.body);
      res.json(question);
    } catch (error) {
      console.error("Error creating question:", error);
      res.status(500).json({ message: "Failed to create question" });
    }
  });

  app.delete("/api/admin/questions/:id", async (req, res) => {
    try {
      await storage.deleteQuestion(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting question:", error);
      res.status(500).json({ message: "Failed to delete question" });
    }
  });

  // Competition routes
  app.get("/api/competitions", async (req, res) => {
    try {
      const competitions = await storage.getActiveCompetitions(10);
      res.json(competitions);
    } catch (error) {
      console.error("Error fetching competitions:", error);
      res.status(500).json({ message: "Failed to fetch competitions" });
    }
  });

  app.post("/api/competitions", async (req, res) => {
    try {
      const competition = await storage.createCompetition(req.body);
      res.json(competition);
    } catch (error) {
      console.error("Error creating competition:", error);
      res.status(500).json({ message: "Failed to create competition" });
    }
  });

  app.post("/api/competitions/:id/join", async (req, res) => {
    try {
      const { userId } = req.body;
      const participant = await storage.joinCompetition(req.params.id, userId);
      res.json(participant);
    } catch (error) {
      console.error("Error joining competition:", error);
      res.status(500).json({ message: "Failed to join competition" });
    }
  });

  // Analytics logging
  app.post("/api/analytics", async (req, res) => {
    try {
      const event = await storage.logAnalyticsEvent(req.body);
      res.json(event);
    } catch (error) {
      console.error("Error logging analytics:", error);
      res.status(500).json({ message: "Failed to log analytics" });
    }
  });

  // Admin routes
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const stats = await storage.getAnalyticsSummary();
      res.json(stats);
    } catch (error) {
      console.error("Error getting admin stats:", error);
      res.status(500).json({ message: "Failed to get admin statistics" });
    }
  });

  app.get("/api/admin/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error getting all users:", error);
      res.status(500).json({ message: "Failed to get users" });
    }
  });

  app.get("/api/admin/questions", async (req, res) => {
    try {
      const questions = await storage.getAllQuestions();
      res.json(questions);
    } catch (error) {
      console.error("Error getting all questions:", error);
      res.status(500).json({ message: "Failed to get questions" });
    }
  });

  app.delete("/api/admin/questions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteQuestion(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting question:", error);
      res.status(500).json({ message: "Failed to delete question" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
