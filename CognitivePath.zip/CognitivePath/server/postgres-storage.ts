import { db } from "./db";
import { 
  users, 
  subjects, 
  questions, 
  quizSessions,
  studyProgress, 
  studyPlanContent,
  type User,
  type InsertUser,
  type Subject, 
  type InsertSubject,
  type Question,
  type InsertQuestion,
  type QuizSession,
  type InsertQuizSession,
  type StudyProgress,
  type InsertStudyProgress,
  type StudyPlanContent,
  type InsertStudyPlanContent
} from "@shared/drizzle-schema";
import { eq, and, desc } from 'drizzle-orm';

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByNickname(nickname: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User>;
  activateUser(id: number, activationCode: string): Promise<User>;

  // Subject operations
  getAllSubjects(): Promise<Subject[]>;
  getSubject(id: number): Promise<Subject | undefined>;
  createSubject(subject: InsertSubject): Promise<Subject>;

  // Question operations
  getQuestionsBySubject(subjectId: number, limit?: number): Promise<Question[]>;
  getQuestion(id: number): Promise<Question | undefined>;
  createQuestion(question: InsertQuestion): Promise<Question>;

  // Quiz session operations
  createQuizSession(session: InsertQuizSession): Promise<QuizSession>;
  getQuizSession(id: number): Promise<QuizSession | undefined>;
  updateQuizSession(id: number, updates: Partial<QuizSession>): Promise<QuizSession>;
  getUserQuizSessions(userId: number): Promise<QuizSession[]>;

  // Study progress operations
  getStudyProgress(userId: number, subjectId: number): Promise<StudyProgress[]>;
  updateStudyProgress(progress: InsertStudyProgress): Promise<StudyProgress>;
  markTopicAsStudied(userId: number, subjectId: number, topic: string): Promise<StudyProgress>;

  // Study plan operations
  getStudyPlanContent(subjectId: number, topic: string): Promise<StudyPlanContent | undefined>;
  saveStudyPlanContent(content: InsertStudyPlanContent): Promise<StudyPlanContent>;

  // Leaderboard operations
  getLeaderboard(limit: number): Promise<Array<{
    id: number;
    nickname: string;
    avatarUrl?: string;
    totalScore: number;
    testsCompleted: number;
  }>>;
}

class PostgresStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async getUserByNickname(nickname: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.nickname, nickname)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const result = await db.update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    
    if (!result[0]) throw new Error("User not found");
    return result[0];
  }

  async activateUser(id: number, activationCode: string): Promise<User> {
    const user = await this.getUser(id);
    if (!user) throw new Error("User not found");
    if (user.activationCode !== activationCode) throw new Error("Invalid activation code");

    const result = await db.update(users)
      .set({ 
        isActivated: true, 
        isPremium: true,
        updatedAt: new Date() 
      })
      .where(eq(users.id, id))
      .returning();

    if (!result[0]) throw new Error("Failed to activate user");
    return result[0];
  }

  // Subject operations
  async getAllSubjects(): Promise<Subject[]> {
    return await db.select().from(subjects);
  }

  async getSubject(id: number): Promise<Subject | undefined> {
    const result = await db.select().from(subjects).where(eq(subjects.id, id)).limit(1);
    return result[0];
  }

  async createSubject(subject: InsertSubject): Promise<Subject> {
    const result = await db.insert(subjects).values(subject).returning();
    return result[0];
  }

  // Question operations
  async getQuestionsBySubject(subjectId: number, limit?: number): Promise<Question[]> {
    let query = db.select().from(questions).where(eq(questions.subjectId, subjectId));
    
    if (limit) {
      query = query.limit(limit);
    }
    
    return await query;
  }

  async getQuestion(id: number): Promise<Question | undefined> {
    const result = await db.select().from(questions).where(eq(questions.id, id)).limit(1);
    return result[0];
  }

  async createQuestion(question: InsertQuestion): Promise<Question> {
    const result = await db.insert(questions).values(question).returning();
    return result[0];
  }

  // Quiz session operations
  async createQuizSession(session: InsertQuizSession): Promise<QuizSession> {
    const result = await db.insert(quizSessions).values(session).returning();
    return result[0];
  }

  async getQuizSession(id: number): Promise<QuizSession | undefined> {
    const result = await db.select().from(quizSessions).where(eq(quizSessions.id, id)).limit(1);
    return result[0];
  }

  async updateQuizSession(id: number, updates: Partial<QuizSession>): Promise<QuizSession> {
    const result = await db.update(quizSessions)
      .set(updates)
      .where(eq(quizSessions.id, id))
      .returning();
    
    if (!result[0]) throw new Error("Quiz session not found");
    return result[0];
  }

  async getUserQuizSessions(userId: number): Promise<QuizSession[]> {
    return await db.select()
      .from(quizSessions)
      .where(eq(quizSessions.userId, userId))
      .orderBy(desc(quizSessions.createdAt));
  }

  // Study progress operations
  async getStudyProgress(userId: number, subjectId: number): Promise<StudyProgress[]> {
    return await db.select()
      .from(studyProgress)
      .where(and(
        eq(studyProgress.userId, userId),
        eq(studyProgress.subjectId, subjectId)
      ));
  }

  async updateStudyProgress(progress: InsertStudyProgress): Promise<StudyProgress> {
    // First check if progress exists
    const existing = await db.select()
      .from(studyProgress)
      .where(and(
        eq(studyProgress.userId, progress.userId!),
        eq(studyProgress.subjectId, progress.subjectId!),
        eq(studyProgress.topic, progress.topic)
      ))
      .limit(1);

    if (existing[0]) {
      const result = await db.update(studyProgress)
        .set({ ...progress, updatedAt: new Date() })
        .where(eq(studyProgress.id, existing[0].id))
        .returning();
      return result[0];
    } else {
      const result = await db.insert(studyProgress).values(progress).returning();
      return result[0];
    }
  }

  async markTopicAsStudied(userId: number, subjectId: number, topic: string): Promise<StudyProgress> {
    return await this.updateStudyProgress({
      userId,
      subjectId,
      topic,
      isCompleted: true
    });
  }

  // Study plan operations
  async getStudyPlanContent(subjectId: number, topic: string): Promise<StudyPlanContent | undefined> {
    const result = await db.select()
      .from(studyPlanContent)
      .where(and(
        eq(studyPlanContent.subjectId, subjectId),
        eq(studyPlanContent.topic, topic)
      ))
      .limit(1);
    
    return result[0];
  }

  async saveStudyPlanContent(content: InsertStudyPlanContent): Promise<StudyPlanContent> {
    const result = await db.insert(studyPlanContent).values(content).returning();
    return result[0];
  }

  // Leaderboard operations
  async getLeaderboard(limit: number): Promise<Array<{
    id: number;
    nickname: string;
    avatarUrl?: string;
    totalScore: number;
    testsCompleted: number;
  }>> {
    const result = await db.select({
      id: users.id,
      nickname: users.nickname,
      avatarUrl: users.avatarUrl,
      totalScore: users.totalScore,
      testsCompleted: users.testsCompleted
    })
    .from(users)
    .orderBy(desc(users.totalScore))
    .limit(limit);

    return result;
  }
}

export const storage = new PostgresStorage();