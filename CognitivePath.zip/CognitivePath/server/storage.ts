import { db } from "./db";
import { eq, desc, and, count } from "drizzle-orm";
import {
  users,
  subjects,
  questions,
  quizSessions,
  studyProgress,
  studyPlanContent,
  competitions,
  competitionParticipants,
  analytics,
  offlineCache,
  explainedQuestions,
  type User,
  type InsertUser,
  type UpsertUser,
  type Subject, 
  type InsertSubject,
  type Question,
  type InsertQuestion,
  type QuizSession,
  type InsertQuizSession,
  type StudyProgress,
  type InsertStudyProgress,
  type StudyPlanContent,
  type InsertStudyPlanContent,
  type Competition,
  type InsertCompetition,
  type CompetitionParticipant,
  type InsertCompetitionParticipant,
  type Analytics,
  type InsertAnalytics,
  type OfflineCache,
  type InsertOfflineCache,
  type ExplainedQuestion,
  type InsertExplainedQuestion
} from "@shared/schema";

export interface IStorage {
  // User operations (including support for admin and usage limiting)
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByNickname(nickname: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User>;
  activateUser(id: string, activationCode: string): Promise<User>;
  incrementUsageCount(userId: string): Promise<User>;
  
  // Subject operations
  getAllSubjects(): Promise<Subject[]>;
  getSubject(id: string): Promise<Subject | undefined>;
  createSubject(subject: InsertSubject): Promise<Subject>;

  // Question operations
  getQuestionsBySubject(subjectId: string, limit?: number): Promise<Question[]>;
  getQuestion(id: string): Promise<Question | undefined>;
  createQuestion(question: InsertQuestion): Promise<Question>;

  // Quiz session operations
  createQuizSession(session: InsertQuizSession): Promise<QuizSession>;
  getQuizSession(id: string): Promise<QuizSession | undefined>;
  updateQuizSession(id: string, updates: Partial<QuizSession>): Promise<QuizSession>;
  getUserQuizSessions(userId: string): Promise<QuizSession[]>;
  
  // Enhanced explained questions operations
  createExplainedQuestion(explainedQuestion: InsertExplainedQuestion): Promise<ExplainedQuestion>;
  getExplainedQuestion(userId: string, questionId: string): Promise<ExplainedQuestion | null>;
  getExplainedQuestionsByUser(userId: string, subjectId?: string, limit?: number): Promise<ExplainedQuestion[]>;
  getExplainedQuestionsBySubject(userId: string, subjectId: string, limit?: number): Promise<ExplainedQuestion[]>;
  updateExplainedQuestion(id: string, updates: Partial<ExplainedQuestion>): Promise<ExplainedQuestion | null>;
  deleteExplainedQuestion(id: string): Promise<boolean>;

  // Study progress operations
  getStudyProgress(userId: string, subjectId: string): Promise<StudyProgress[]>;
  updateStudyProgress(progress: InsertStudyProgress): Promise<StudyProgress>;
  markTopicAsStudied(userId: string, subjectId: string, topic: string): Promise<StudyProgress>;

  // Study plan operations
  getStudyPlanContent(subjectId: string, topic: string): Promise<StudyPlanContent | undefined>;
  saveStudyPlanContent(content: InsertStudyPlanContent): Promise<StudyPlanContent>;

  // Leaderboard operations
  getLeaderboard(limit: number): Promise<Array<{
    id: string;
    nickname: string;
    avatarUrl?: string;
    totalScore: number;
    testsCompleted: number;
  }>>;

  // Competition operations
  createCompetition(competition: InsertCompetition): Promise<Competition>;
  getCompetition(id: string): Promise<Competition | undefined>;
  updateCompetition(id: string, updates: Partial<Competition>): Promise<Competition>;
  joinCompetition(competitionId: string, userId: string): Promise<CompetitionParticipant>;
  getCompetitionParticipants(competitionId: string): Promise<CompetitionParticipant[]>;
  updateCompetitionParticipant(id: string, updates: Partial<CompetitionParticipant>): Promise<CompetitionParticipant>;
  getActiveCompetitions(limit: number): Promise<Competition[]>;

  // Analytics operations
  logAnalyticsEvent(event: InsertAnalytics): Promise<Analytics>;
  getAnalyticsData(userId?: string, eventType?: string, limit?: number): Promise<Analytics[]>;

  // Offline cache operations
  getCachedContent(userId: string, subjectId: string, contentType: string): Promise<OfflineCache | undefined>;
  cacheContent(cache: InsertOfflineCache): Promise<OfflineCache>;
  
  // Admin operations
  getAllUsers(): Promise<User[]>;
  getAllQuestions(): Promise<Question[]>;
  deleteQuestion(id: string): Promise<void>;
  getAnalyticsSummary(): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUserByNickname(nickname: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.nickname, nickname));
    return user || undefined;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    if (userData.id) {
      const [user] = await db
        .update(users)
        .set({ ...userData, updatedAt: new Date() })
        .where(eq(users.id, userData.id))
        .returning();
      return user;
    } else {
      const [user] = await db
        .insert(users)
        .values(userData)
        .returning();
      return user;
    }
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    
    if (!updatedUser) throw new Error("User not found");
    return updatedUser;
  }

  async activateUser(id: string, activationCode: string): Promise<User> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    if (!user) throw new Error("User not found");
    if (user.activationCode !== activationCode) throw new Error("Invalid activation code");

    const [updatedUser] = await db
      .update(users)
      .set({
        isActivated: true,
        isPremium: true,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();

    if (!updatedUser) throw new Error("Failed to activate user");
    return updatedUser;
  }

  async incrementUsageCount(userId: string): Promise<User> {
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    if (!user) throw new Error("User not found");
    
    const [updatedUser] = await db
      .update(users)
      .set({
        usageCount: (user.usageCount || 0) + 1,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    
    if (!updatedUser) throw new Error("User not found");
    return updatedUser;
  }

  // Subject operations  
  async getAllSubjects(): Promise<Subject[]> {
    return await db.select().from(subjects);
  }

  async getSubject(id: string): Promise<Subject | undefined> {
    const [subject] = await db.select().from(subjects).where(eq(subjects.id, id));
    return subject || undefined;
  }

  async createSubject(subjectData: InsertSubject): Promise<Subject> {
    const [subject] = await db
      .insert(subjects)
      .values(subjectData)
      .returning();
    return subject;
  }

  // Question operations
  async getQuestionsBySubject(subjectId: string, limit?: number): Promise<Question[]> {
    const query = db.select().from(questions).where(eq(questions.subjectId, subjectId));
    return limit ? await query.limit(limit) : await query;
  }

  async getQuestion(id: string): Promise<Question | undefined> {
    const [question] = await db.select().from(questions).where(eq(questions.id, id));
    return question || undefined;
  }

  async createQuestion(questionData: InsertQuestion): Promise<Question> {
    const [question] = await db
      .insert(questions)
      .values(questionData)
      .returning();
    return question;
  }

  // Quiz session operations
  async createQuizSession(sessionData: InsertQuizSession): Promise<QuizSession> {
    const [session] = await db
      .insert(quizSessions)
      .values(sessionData)
      .returning();
    return session;
  }

  async getQuizSession(id: string): Promise<QuizSession | undefined> {
    const [session] = await db.select().from(quizSessions).where(eq(quizSessions.id, id));
    return session || undefined;
  }

  async updateQuizSession(id: string, updates: Partial<QuizSession>): Promise<QuizSession> {
    const [updatedSession] = await db
      .update(quizSessions)
      .set(updates)
      .where(eq(quizSessions.id, id))
      .returning();
    
    if (!updatedSession) throw new Error("Quiz session not found");
    return updatedSession;
  }

  async getUserQuizSessions(userId: string): Promise<QuizSession[]> {
    return await db
      .select()
      .from(quizSessions)
      .where(eq(quizSessions.userId, userId))
      .orderBy(desc(quizSessions.startedAt));
  }

  // Study progress operations
  async getStudyProgress(userId: string, subjectId: string): Promise<StudyProgress[]> {
    return await db
      .select()
      .from(studyProgress)
      .where(and(
        eq(studyProgress.userId, userId),
        eq(studyProgress.subjectId, subjectId)
      ));
  }

  async updateStudyProgress(progressData: InsertStudyProgress): Promise<StudyProgress> {
    const [existing] = await db
      .select()
      .from(studyProgress)
      .where(and(
        eq(studyProgress.userId, progressData.userId),
        eq(studyProgress.subjectId, progressData.subjectId),
        eq(studyProgress.topic, progressData.topic)
      ));

    if (existing) {
      const [updated] = await db
        .update(studyProgress)
        .set(progressData)
        .where(eq(studyProgress.id, existing.id))
        .returning();
      return updated;
    } else {
      const [newProgress] = await db
        .insert(studyProgress)
        .values(progressData)
        .returning();
      return newProgress;
    }
  }

  async markTopicAsStudied(userId: string, subjectId: string, topic: string): Promise<StudyProgress> {
    const [existing] = await db
      .select()
      .from(studyProgress)
      .where(and(
        eq(studyProgress.userId, userId),
        eq(studyProgress.subjectId, subjectId),
        eq(studyProgress.topic, topic)
      ));

    const updateData = {
      userId,
      subjectId,
      topic,
      isCompleted: true,
      completedAt: new Date(),
      timeSpent: 0,
    };

    if (existing) {
      const [updated] = await db
        .update(studyProgress)
        .set(updateData)
        .where(eq(studyProgress.id, existing.id))
        .returning();
      return updated;
    } else {
      const [newProgress] = await db
        .insert(studyProgress)
        .values(updateData)
        .returning();
      return newProgress;
    }
  }

  // Study plan operations
  async getStudyPlanContent(subjectId: string, topic: string): Promise<StudyPlanContent | undefined> {
    const [content] = await db
      .select()
      .from(studyPlanContent)
      .where(and(
        eq(studyPlanContent.subjectId, subjectId),
        eq(studyPlanContent.topic, topic)
      ));
    return content || undefined;
  }

  async saveStudyPlanContent(contentData: InsertStudyPlanContent): Promise<StudyPlanContent> {
    const [content] = await db
      .insert(studyPlanContent)
      .values(contentData)
      .returning();
    return content;
  }

  // Leaderboard operations
  async getLeaderboard(limit: number): Promise<Array<{
    id: string;
    nickname: string;
    avatarUrl?: string;
    totalScore: number;
    testsCompleted: number;
  }>> {
    const result = await db
      .select({
        id: users.id,
        nickname: users.nickname,
        avatarUrl: users.avatarUrl,
        totalScore: users.totalScore,
        testsCompleted: users.testsCompleted,
      })
      .from(users)
      .orderBy(desc(users.totalScore))
      .limit(limit);

    return result.map(u => ({
      id: u.id,
      nickname: u.nickname,
      avatarUrl: u.avatarUrl || undefined,
      totalScore: u.totalScore || 0,
      testsCompleted: u.testsCompleted || 0
    }));
  }

  // Competition operations
  async createCompetition(competitionData: InsertCompetition): Promise<Competition> {
    const [competition] = await db
      .insert(competitions)
      .values(competitionData)
      .returning();
    return competition;
  }

  async getCompetition(id: string): Promise<Competition | undefined> {
    const [competition] = await db.select().from(competitions).where(eq(competitions.id, id));
    return competition || undefined;
  }

  async updateCompetition(id: string, updates: Partial<Competition>): Promise<Competition> {
    const [updated] = await db
      .update(competitions)
      .set(updates)
      .where(eq(competitions.id, id))
      .returning();
    
    if (!updated) throw new Error("Competition not found");
    return updated;
  }

  async joinCompetition(competitionId: string, userId: string): Promise<CompetitionParticipant> {
    const [participant] = await db
      .insert(competitionParticipants)
      .values({
        competitionId,
        userId,
        score: 0,
        timeSpent: 0,
        answers: []
      })
      .returning();
    return participant;
  }

  async getCompetitionParticipants(competitionId: string): Promise<CompetitionParticipant[]> {
    return await db
      .select()
      .from(competitionParticipants)
      .where(eq(competitionParticipants.competitionId, competitionId));
  }

  async updateCompetitionParticipant(id: string, updates: Partial<CompetitionParticipant>): Promise<CompetitionParticipant> {
    const [updated] = await db
      .update(competitionParticipants)
      .set(updates)
      .where(eq(competitionParticipants.id, id))
      .returning();
    
    if (!updated) throw new Error("Participant not found");
    return updated;
  }

  async getActiveCompetitions(limit: number): Promise<Competition[]> {
    return await db
      .select()
      .from(competitions)
      .where(eq(competitions.status, "active"))
      .orderBy(desc(competitions.createdAt))
      .limit(limit);
  }

  // Analytics operations
  async logAnalyticsEvent(eventData: InsertAnalytics): Promise<Analytics> {
    const [event] = await db
      .insert(analytics)
      .values(eventData)
      .returning();
    return event;
  }

  async getAnalyticsData(userId?: string, eventType?: string, limit = 100): Promise<Analytics[]> {
    const conditions = [];
    if (userId) conditions.push(eq(analytics.userId, userId));
    if (eventType) conditions.push(eq(analytics.eventType, eventType));
    
    const baseQuery = db.select().from(analytics);
    const query = conditions.length > 0 ? baseQuery.where(and(...conditions)) : baseQuery;
    
    return await query
      .orderBy(desc(analytics.timestamp))
      .limit(limit);
  }

  // Offline cache operations
  async getCachedContent(userId: string, subjectId: string, contentType: string): Promise<OfflineCache | undefined> {
    const [cached] = await db
      .select()
      .from(offlineCache)
      .where(and(
        eq(offlineCache.userId, userId),
        eq(offlineCache.subjectId, subjectId),
        eq(offlineCache.contentType, contentType)
      ));
    return cached || undefined;
  }

  async cacheContent(cacheData: InsertOfflineCache): Promise<OfflineCache> {
    const [existing] = await db
      .select()
      .from(offlineCache)
      .where(and(
        eq(offlineCache.userId, cacheData.userId),
        eq(offlineCache.subjectId, cacheData.subjectId),
        eq(offlineCache.contentType, cacheData.contentType)
      ));

    if (existing) {
      const [updated] = await db
        .update(offlineCache)
        .set({ ...cacheData, lastSynced: new Date() })
        .where(eq(offlineCache.id, existing.id))
        .returning();
      return updated;
    } else {
      const [newCache] = await db
        .insert(offlineCache)
        .values(cacheData)
        .returning();
      return newCache;
    }
  }

  // Explained questions operations
  async createExplainedQuestion(explainedQuestionData: InsertExplainedQuestion): Promise<ExplainedQuestion> {
    const [existing] = await db
      .select()
      .from(explainedQuestions)
      .where(and(
        eq(explainedQuestions.userId, explainedQuestionData.userId),
        eq(explainedQuestions.questionId, explainedQuestionData.questionId)
      ));
    
    if (existing) {
      // Update existing explanation instead of creating duplicate
      const [updated] = await db
        .update(explainedQuestions)
        .set(explainedQuestionData)
        .where(eq(explainedQuestions.id, existing.id))
        .returning();
      return updated;
    }
    
    const [explainedQuestion] = await db
      .insert(explainedQuestions)
      .values(explainedQuestionData)
      .returning();
    return explainedQuestion;
  }

  async getExplainedQuestion(userId: string, questionId: string): Promise<ExplainedQuestion | null> {
    const [explainedQuestion] = await db
      .select()
      .from(explainedQuestions)
      .where(and(
        eq(explainedQuestions.userId, userId),
        eq(explainedQuestions.questionId, questionId)
      ));
    return explainedQuestion || null;
  }

  async getExplainedQuestionsByUser(userId: string, subjectId?: string, limit?: number): Promise<ExplainedQuestion[]> {
    const conditions = [eq(explainedQuestions.userId, userId)];
    if (subjectId) {
      conditions.push(eq(explainedQuestions.subjectId, subjectId));
    }
    
    const baseQuery = db.select().from(explainedQuestions).where(and(...conditions)).orderBy(desc(explainedQuestions.explainedAt));
    
    return limit ? await baseQuery.limit(limit) : await baseQuery;
  }

  async getExplainedQuestionsBySubject(userId: string, subjectId: string, limit?: number): Promise<ExplainedQuestion[]> {
    const baseQuery = db
      .select()
      .from(explainedQuestions)
      .where(and(
        eq(explainedQuestions.userId, userId),
        eq(explainedQuestions.subjectId, subjectId)
      ))
      .orderBy(desc(explainedQuestions.explainedAt));
      
    return limit ? await baseQuery.limit(limit) : await baseQuery;
  }

  async updateExplainedQuestion(id: string, updates: Partial<ExplainedQuestion>): Promise<ExplainedQuestion | null> {
    const [updated] = await db
      .update(explainedQuestions)
      .set(updates)
      .where(eq(explainedQuestions.id, id))
      .returning();
    
    return updated || null;
  }

  async deleteExplainedQuestion(id: string): Promise<boolean> {
    const result = await db
      .delete(explainedQuestions)
      .where(eq(explainedQuestions.id, id));
    
    return (result.rowCount || 0) > 0;
  }

  // Admin operations
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getAllQuestions(): Promise<Question[]> {
    return await db.select().from(questions);
  }

  async deleteQuestion(id: string): Promise<void> {
    await db.delete(questions).where(eq(questions.id, id));
  }

  async getAnalyticsSummary(): Promise<any> {
    const totalUsers = await db.select().from(users);
    const totalQuestions = await db.select().from(questions);
    const totalSessions = await db.select().from(quizSessions);
    
    return {
      totalUsers: totalUsers.length,
      totalQuestions: totalQuestions.length,
      totalSessions: totalSessions.length,
      activeUsers: totalUsers.filter(u => u.isActivated).length
    };
  }
}

export const storage = new DatabaseStorage();