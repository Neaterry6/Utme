import { GoogleGenAI } from "@google/genai";
import OpenAI from "openai";

// Initialize AI clients
const gemini = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "" });
const grok = new OpenAI({ 
  baseURL: "https://api.x.ai/v1", 
  apiKey: process.env.XAI_API_KEY || "" 
});

export class AIService {
  async generateStudyPlan(subject: string, topic: string, aiModel: string = 'gemini'): Promise<string> {
    const prompt = `Create a comprehensive study plan for ${topic} in ${subject}. 

    Include:
    1. Overview of the topic
    2. Key concepts to understand
    3. Learning objectives
    4. Study strategies and tips
    5. Practice exercises suggestions
    6. Common exam questions patterns
    7. Real-world applications

    Format the response in markdown for easy reading. Make it engaging and educational for POST UTME students.`;

    try {
      switch (aiModel) {
        case 'gemini':
          return await this.generateWithGemini(prompt);
        case 'gpt4':
          return await this.generateWithOpenAI(prompt);
        case 'grok':
          return await this.generateWithGrok(prompt);
        default:
          return await this.generateWithGemini(prompt);
      }
    } catch (error) {
      console.error(`Error generating study plan with ${aiModel}:`, error);
      // Fallback to a basic study plan
      return this.getFallbackStudyPlan(subject, topic);
    }
  }

  async generateExplanation(
    question: string,
    correctAnswer: string,
    userAnswer: string,
    aiModel: string = 'gemini'
  ): Promise<string> {
    const prompt = `Explain why the correct answer is "${correctAnswer}" for this question:

    Question: ${question}
    Student's answer: ${userAnswer}
    Correct answer: ${correctAnswer}

    Provide a clear, educational explanation that helps the student understand:
    1. Why the correct answer is right
    2. Why their answer (if different) was incorrect
    3. Key concepts to remember
    4. Tips for similar questions

    Keep the explanation concise but thorough, suitable for POST UTME students.`;

    try {
      switch (aiModel) {
        case 'gemini':
          return await this.generateWithGemini(prompt);
        case 'gpt4':
          return await this.generateWithOpenAI(prompt);
        case 'grok':
          return await this.generateWithGrok(prompt);
        default:
          return await this.generateWithGemini(prompt);
      }
    } catch (error) {
      console.error(`Error generating explanation with ${aiModel}:`, error);
      return `The correct answer is ${correctAnswer}. Please review the relevant concepts in your study materials.`;
    }
  }

  private async generateWithGemini(prompt: string): Promise<string> {
    const response = await gemini.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    return response.text || "Unable to generate content at this time.";
  }

  private async generateWithOpenAI(prompt: string): Promise<string> {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [{ role: "user", content: prompt }],
      max_tokens: 2000,
    });

    return response.choices[0].message.content || "Unable to generate content at this time.";
  }

  private async generateWithGrok(prompt: string): Promise<string> {
    const response = await grok.chat.completions.create({
      model: "grok-2-1212",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 2000,
    });

    return response.choices[0].message.content || "Unable to generate content at this time.";
  }

  private getFallbackStudyPlan(subject: string, topic: string): string {
    return `# Study Plan: ${topic} (${subject})

## Overview
This topic is an important part of ${subject} that requires focused study and practice.

## Key Concepts
- Understand the fundamental principles
- Practice with examples
- Review past questions
- Connect to real-world applications

## Study Strategies
1. Read your textbook chapter thoroughly
2. Take notes on key points
3. Practice with sample questions
4. Form study groups for discussion
5. Use online resources for additional examples

## Practice Tips
- Start with basic concepts before moving to complex problems
- Time yourself when practicing questions
- Review mistakes and understand why they occurred
- Seek help when needed

## Exam Preparation
- Review all notes regularly
- Practice past exam questions
- Focus on frequently tested areas
- Manage your time effectively during exams

Remember: Consistent practice and understanding of concepts is key to success!`;
  }
}

export const aiService = new AIService();
