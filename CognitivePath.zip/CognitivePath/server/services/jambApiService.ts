// Use global fetch instead of node-fetch for better compatibility

interface JambQuestion {
  id: string;
  question: string;
  option: {
    a: string;
    b: string;
    c: string;
    d: string;
  };
  answer: string;
  image?: string;
  explanation?: string;
  examtype: string;
  examyear: string;
  subject: string;
}

interface AlocApiResponse {
  data: JambQuestion[];
  meta?: {
    total: number;
    page: number;
    per_page: number;
  };
}

class JambApiService {
  private readonly baseUrl = 'https://questions.aloc.com.ng/api/v2';
  private readonly maxRetries = 3;
  private readonly retryDelay = 1000; // 1 second

  // Subject mapping from our system to ALOC API format (exact API subject names)
  private subjectMapping: Record<string, string> = {
    'english': 'english',
    'mathematics': 'mathematics', 
    'biology': 'biology',
    'physics': 'physics',
    'chemistry': 'chemistry',
    'economics': 'economics',
    'government': 'government',
    'literature': 'englishlit',
    'geography': 'geography',
    'commerce': 'commerce',
    'accounting': 'accounting',
    'crk': 'crk',
    'irk': 'irk',
    'civiledu': 'civiledu',
    'history': 'history'
  };

  /**
   * Fetch multiple unique questions from ALOC API with retry logic
   */
  async fetchQuestions(
    subject: string, 
    options: {
      limit?: number;
      year?: string | number;
      type?: 'utme' | 'wassce' | 'neco' | 'post-utme';
      accessToken?: string;
    } = {}
  ): Promise<JambQuestion[]> {
    const { limit = 20, year, type = 'utme', accessToken } = options;
    
    // Use the exact subject name from our database
    const apiSubject = this.subjectMapping[subject.toLowerCase()] || 'english';
    
    const headers: Record<string, string> = {
      'Accept': 'application/json',
      'User-Agent': 'CBT-Platform/1.0',
      'AccessToken': accessToken || 'QB-139d5195a490b3c12794'
    };

    const questions: JambQuestion[] = [];
    const fetchedIds = new Set<string>();
    
    // Fetch multiple different questions by making individual requests
    for (let i = 0; i < limit && i < 50; i++) {
      for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
        try {
          // Build URL parameters for each request
          const params = new URLSearchParams({
            subject: apiSubject,
            type: type || 'utme'
          });

          if (year) {
            params.append('year', year.toString());
          }

          const url = `${this.baseUrl}/q?${params.toString()}`;
          
          console.log(`Fetching question ${i + 1}/${limit} from: ${url} (Attempt ${attempt})`);
          
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 8000); // 8 second timeout
          
          const response = await fetch(url, {
            method: 'GET',
            headers,
            signal: controller.signal
          });
          
          clearTimeout(timeoutId);

          if (!response.ok) {
            throw new Error(`API request failed: ${response.status} ${response.statusText}`);
          }

          const data = await response.json() as any;
          
          // Handle ALOC API response format
          if (data.data && typeof data.data === 'object' && 'question' in data.data) {
            const question = data.data;
            const questionId = question.id || `${question.question.substring(0, 50)}`;
            
            // Only add unique questions
            if (!fetchedIds.has(questionId)) {
              fetchedIds.add(questionId);
              questions.push(question);
              break; // Success, move to next question
            }
          }
          
          // Add small delay between requests to avoid rate limiting
          await new Promise(resolve => setTimeout(resolve, 100));
          break; // Success, move to next question

        } catch (error) {
          console.error(`Question ${i + 1}, Attempt ${attempt} failed:`, error);
          
          if (attempt === this.maxRetries) {
            console.error(`Failed to fetch question ${i + 1} after all retries`);
            break; // Move to next question
          }
          
          // Wait before retrying
          await new Promise(resolve => setTimeout(resolve, this.retryDelay * attempt));
        }
      }
    }

    console.log(`Successfully fetched ${questions.length} unique questions for ${subject}`);
    return questions;
  }



  /**
   * Convert JAMB API question to our internal format
   */
  formatQuestion(jambQuestion: JambQuestion, index: number): any {
    const options = [
      { id: 'A', text: jambQuestion.option.a },
      { id: 'B', text: jambQuestion.option.b },
      { id: 'C', text: jambQuestion.option.c },
      { id: 'D', text: jambQuestion.option.d }
    ];

    return {
      id: jambQuestion.id || `jamb_${index}`,
      question: jambQuestion.question,
      options,
      correctAnswer: jambQuestion.answer.toUpperCase(),
      subject: jambQuestion.subject || 'General',
      difficulty: 'medium',
      explanation: jambQuestion.explanation || `The correct answer is ${jambQuestion.answer.toUpperCase()}. This is from ${jambQuestion.examtype} ${jambQuestion.examyear}.`,
      imageUrl: jambQuestion.image || null,
      year: parseInt(jambQuestion.examyear) || new Date().getFullYear(),
      examType: jambQuestion.examtype || 'UTME',
      source: 'JAMB Past Questions',
      tags: [jambQuestion.subject, jambQuestion.examtype, jambQuestion.examyear].filter(Boolean)
    };
  }

  /**
   * Get available subjects from the API
   */
  getAvailableSubjects(): string[] {
    return Object.keys(this.subjectMapping);
  }

  /**
   * Validate if a subject is supported
   */
  isSubjectSupported(subject: string): boolean {
    return subject.toLowerCase() in this.subjectMapping;
  }

  /**
   * Get available years for ALOC API (based on documentation)
   */
  getAvailableYears(): number[] {
    const years: number[] = [];
    for (let year = 2001; year <= 2020; year++) {
      years.push(year);
    }
    return years.reverse(); // Most recent first
  }

  /**
   * Get available exam types
   */
  getAvailableExamTypes(): string[] {
    return ['utme', 'wassce', 'neco', 'post-utme'];
  }

  /**
   * Fallback questions when API fails
   */
  getFallbackQuestions(subject: string, limit: number): JambQuestion[] {
    console.log(`Generating fallback questions for ${subject}`);
    
    const fallbackQuestions: JambQuestion[] = [];
    
    for (let i = 0; i < Math.min(limit, 5); i++) {
      fallbackQuestions.push({
        id: `fallback_${subject}_${i}`,
        question: `Sample ${subject} question ${i + 1}. This is a fallback question when the API is unavailable.`,
        option: {
          a: 'Option A',
          b: 'Option B', 
          c: 'Option C',
          d: 'Option D'
        },
        answer: 'A',
        explanation: 'This is a fallback question. Please check your internet connection and try again.',
        examtype: 'UTME',
        examyear: '2024',
        subject: subject
      });
    }
    
    return fallbackQuestions;
  }
}

export const jambApiService = new JambApiService();

// Export individual functions for direct use
export const getFallbackQuestions = (subject: string, limit: number) => {
  return jambApiService.getFallbackQuestions(subject, limit);
};