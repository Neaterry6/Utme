// AI Service for generating explanations using multiple providers
import { GoogleGenerativeAI } from "@google/genai";

interface AIExplanationRequest {
  question: string;
  correctAnswer: string;
  options: { id: string; text: string }[];
  subject: string;
}

interface AIExplanationResponse {
  explanation: string;
  provider: 'gemini' | 'openai' | 'fallback';
}

class AIService {
  private gemini: GoogleGenerativeAI | null = null;
  private openaiApiKey: string | null = null;

  constructor() {
    // Initialize Gemini if API key is available
    if (process.env.GEMINI_API_KEY) {
      this.gemini = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    }
    
    // Store OpenAI API key if available
    if (process.env.OPENAI_API_KEY) {
      this.openaiApiKey = process.env.OPENAI_API_KEY;
    }
  }

  async generateExplanation(request: AIExplanationRequest): Promise<AIExplanationResponse> {
    const prompt = this.buildPrompt(request);

    // Try Gemini first
    if (this.gemini) {
      try {
        const result = await this.callGemini(prompt);
        return {
          explanation: result,
          provider: 'gemini'
        };
      } catch (error) {
        console.warn('Gemini API failed, trying OpenAI:', error);
      }
    }

    // Try OpenAI as fallback
    if (this.openaiApiKey) {
      try {
        const result = await this.callOpenAI(prompt);
        return {
          explanation: result,
          provider: 'openai'
        };
      } catch (error) {
        console.warn('OpenAI API failed:', error);
      }
    }

    // Return fallback explanation
    return {
      explanation: this.getFallbackExplanation(request),
      provider: 'fallback'
    };
  }

  private buildPrompt(request: AIExplanationRequest): string {
    const { question, correctAnswer, options, subject } = request;
    
    const optionsText = options.map(opt => `${opt.id}. ${opt.text}`).join('\n');
    const correctOption = options.find(opt => opt.id === correctAnswer);
    
    return `As an expert ${subject} teacher, explain this question clearly and educationally:

Question: ${question}

Options:
${optionsText}

Correct Answer: ${correctAnswer}. ${correctOption?.text}

Please provide a detailed explanation that:
1. Explains why the correct answer is right
2. Briefly explains why other options are incorrect (if relevant)
3. Provides additional context or learning tips
4. Uses clear, student-friendly language

Keep the explanation concise but comprehensive, suitable for POST-UTME students.`;
  }

  private async callGemini(prompt: string): Promise<string> {
    if (!this.gemini) throw new Error('Gemini not initialized');
    
    const model = this.gemini.getGenerativeModel({ model: "gemini-pro" });
    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text();
  }

  private async callOpenAI(prompt: string): Promise<string> {
    if (!this.openaiApiKey) throw new Error('OpenAI API key not available');

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.openaiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4', // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: 'system',
            content: 'You are an expert educational assistant helping students understand academic concepts.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 500,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  }

  private getFallbackExplanation(request: AIExplanationRequest): string {
    const { question, correctAnswer, options, subject } = request;
    const correctOption = options.find(opt => opt.id === correctAnswer);
    
    return `The correct answer is ${correctAnswer}. ${correctOption?.text}.

This is a ${subject} question that tests fundamental concepts. The correct answer demonstrates the key principle being examined.

For more detailed explanations, please ensure AI services are properly configured with valid API keys.

Study tip: Review your ${subject} textbook and practice similar questions to strengthen your understanding of this topic.`;
  }

  // Method to enhance existing explanation with AI
  async enhanceExplanation(basicExplanation: string, request: AIExplanationRequest): Promise<AIExplanationResponse> {
    const enhancePrompt = `
Improve and expand this basic explanation for a ${request.subject} question:

Question: ${request.question}
Current explanation: ${basicExplanation}

Please provide a more detailed, engaging explanation that:
1. Builds upon the existing explanation
2. Adds educational context
3. Includes study tips or mnemonics if applicable
4. Maintains clarity for POST-UTME students

Enhanced explanation:`;

    // Try to enhance with AI, fallback to original if fails
    try {
      if (this.gemini) {
        const enhanced = await this.callGemini(enhancePrompt);
        return {
          explanation: enhanced,
          provider: 'gemini'
        };
      } else if (this.openaiApiKey) {
        const enhanced = await this.callOpenAI(enhancePrompt);
        return {
          explanation: enhanced,
          provider: 'openai'
        };
      }
    } catch (error) {
      console.warn('Failed to enhance explanation with AI:', error);
    }

    // Return original explanation if AI enhancement fails
    return {
      explanation: basicExplanation,
      provider: 'fallback'
    };
  }
}

// Export singleton instance
export const aiService = new AIService();
export type { AIExplanationRequest, AIExplanationResponse };