import { useState, useEffect } from 'react';
import { X, ExternalLink } from 'lucide-react';

const AD_IMAGES = [
  'https://tiny.one/k8984wkm',
  'https://tiny.one/82b4964f',
  'https://tiny.one/ndvsbraa',
  'https://tiny.one/yc7a3rcj'
];

export default function MovingAds() {
  const [currentAdIndex, setCurrentAdIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  const [position, setPosition] = useState({ x: 20, y: 100 });

  useEffect(() => {
    // Rotate through ads every 10 seconds
    const adRotationInterval = setInterval(() => {
      setCurrentAdIndex((prevIndex) => (prevIndex + 1) % AD_IMAGES.length);
    }, 10000);

    // Move the ad banner around the screen
    const moveInterval = setInterval(() => {
      setPosition({
        x: Math.random() * (window.innerWidth - 320), // 320px is banner width
        y: Math.random() * (window.innerHeight - 180) + 80, // 180px is banner height, +80 for header
      });
    }, 8000);

    return () => {
      clearInterval(adRotationInterval);
      clearInterval(moveInterval);
    };
  }, []);

  if (!isVisible) return null;

  return (
    <div
      className="fixed z-40 transition-all duration-1000 ease-in-out bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-600 rounded-xl shadow-2xl border-2 border-white/20 backdrop-blur-lg"
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        width: '320px',
        height: '180px',
      }}
      data-testid="moving-ad-banner"
    >
      {/* Close button */}
      <button
        onClick={() => setIsVisible(false)}
        className="absolute top-2 right-2 w-6 h-6 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center text-white z-10 transition-colors"
        data-testid="close-ad-button"
      >
        <X className="h-3 w-3" />
      </button>

      {/* Ad content */}
      <div className="relative w-full h-full overflow-hidden rounded-xl">
        {/* Background image */}
        <img
          src={AD_IMAGES[currentAdIndex]}
          alt="Advertisement"
          className="w-full h-full object-cover"
          onError={(e) => {
            // Fallback if image fails to load
            const target = e.target as HTMLImageElement;
            target.style.display = 'none';
          }}
        />
        
        {/* Overlay content */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex flex-col justify-end p-4">
          <div className="text-white">
            <h3 className="text-sm font-bold mb-1">UI POST UTME</h3>
            <p className="text-xs opacity-90 mb-2">Premium Study Materials</p>
            <a
              href="https://wa.me/message/HJKL7890" // Replace with actual WhatsApp link
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-1 bg-green-600 hover:bg-green-700 px-3 py-1 rounded-full text-xs font-medium transition-colors"
              data-testid="whatsapp-link"
            >
              <span>Contact on WhatsApp</span>
              <ExternalLink className="h-3 w-3" />
            </a>
          </div>
        </div>

        {/* Animated border */}
        <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-purple-400 via-blue-400 to-indigo-400 opacity-50 animate-pulse pointer-events-none"></div>
      </div>

      {/* Ad indicator dots */}
      <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex space-x-1">
        {AD_IMAGES.map((_, index) => (
          <div
            key={index}
            className={`w-2 h-2 rounded-full transition-colors ${
              index === currentAdIndex ? 'bg-white' : 'bg-white/50'
            }`}
          />
        ))}
      </div>
    </div>
  );
}