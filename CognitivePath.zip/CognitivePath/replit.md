# CBT Learning Platform

## Overview

A comprehensive Computer-Based Test (CBT) learning platform designed for Nigerian examination preparation (JAMB, WAEC, NECO, POST-UTME). Features year-specific question practice (2001-2020), AI-powered explanations, beautiful success animations, and comprehensive post-quiz review. Built with real-time quiz functionality, authentic ALOC API integration, and detailed performance analytics.

## Recent Changes

### Enhanced CBT Quiz System (August 2025)
- **Year Selection**: Students can practice with questions from specific examination years (2001-2020)
- **Exam Type Support**: UTME, WASSCE, NECO, and POST-UTME question types
- **Non-Repeating Questions**: Improved question fetching to prevent duplicates within sessions  
- **Post-Quiz Review**: Complete review interface with question-by-question analysis
- **AI Explanations**: Generate and save AI-powered explanations for any question
- **Success Animations**: Celebratory confetti effects and performance analysis on completion
- **Enhanced Storage**: Full quiz session data preservation for review and analytics

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Framework**: Custom component library built on Radix UI primitives with shadcn/ui styling
- **State Management**: TanStack Query for server state management with custom hooks for local state
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with CSS variables for theming and dark mode support
- **Component Structure**: Modular architecture with reusable UI components, custom hooks, and page-level components

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints with consistent error handling and logging middleware
- **File Handling**: Multer for image uploads with memory storage
- **Development**: Hot module replacement with Vite integration for seamless development experience

### Database Architecture
- **Database**: PostgreSQL with Neon serverless hosting
- **ORM**: Drizzle ORM with TypeScript-first approach
- **Schema Design**: 
  - Users table with authentication, premium status, and usage tracking
  - Subjects and Questions for quiz content with ALOC API integration
  - Enhanced Quiz Sessions with complete question storage, user answers, and AI explanations
  - Study Progress and Analytics for learning insights
  - Study Plan Content for AI-generated materials
  - Competition and Leaderboard features
  - Explained Questions with AI-powered explanations and review functionality
- **Data Management**: Drizzle schema with automatic migrations and type safety
- **Quiz Storage**: Complete session data including questionsData, userAnswers, and timeSpent for post-quiz review

### Authentication & Authorization
- **Strategy**: Simple nickname-based registration with local storage persistence
- **Premium Features**: Stripe integration for subscription management
- **User Management**: Profile creation with avatar upload support
- **Session Handling**: Client-side session management with API validation

### AI Service Integration
- **Multi-Provider Support**: Google Gemini, OpenAI GPT-4, and Grok API integration
- **Study Plan Generation**: AI-powered personalized study content creation
- **Question Explanations**: Automated explanations for quiz answers
- **Fallback Strategy**: Graceful degradation when AI services are unavailable

## External Dependencies

### Payment Processing
- **Stripe**: Complete payment infrastructure for premium subscriptions
- **Integration**: React Stripe.js for frontend payment forms
- **Webhooks**: Server-side webhook handling for subscription events

### AI Services
- **Google Gemini**: Primary AI service for content generation
- **OpenAI GPT-4**: Alternative AI provider for enhanced responses
- **Grok API**: Additional AI option for diverse content generation

### Database & Storage
- **PostgreSQL**: Relational database with ACID compliance and strong consistency
- **Drizzle ORM**: Type-safe database operations with automatic schema migrations
- **Neon**: Serverless PostgreSQL hosting with WebSocket support

### Third-Party APIs
- **ALOC API**: Nigerian examination questions API with years 2001-2020 coverage
  - Access token: QB-139d5195a490b3c12794
  - Exam types: UTME, WASSCE, NECO, POST-UTME
  - Subject mapping for authentic past questions
- **Wikipedia API**: Educational content search and retrieval
- **REST API Integration**: Structured data fetching for research functionality

### Development Tools
- **Replit Integration**: Development environment optimization with runtime error handling
- **Vite Plugins**: Hot reload and development enhancement tools
- **TypeScript**: Full type safety across frontend and backend with shared type definitions
- **Drizzle Kit**: Database migrations and schema management tools

### UI Libraries
- **Radix UI**: Headless component primitives for accessibility
- **Lucide React**: Consistent icon system throughout the application
- **Tailwind CSS**: Utility-first styling with custom design system

### Deployment & Build
- **Build Process**: Vite for frontend bundling and esbuild for backend compilation
- **Static Assets**: Optimized asset handling with Vite's asset pipeline
- **Environment Management**: Environment-specific configuration for different deployment stages

## Recent Changes (August 12, 2025)

### Database Migration Completed
- ✅ Successfully migrated from MongoDB/Mongoose to PostgreSQL/Drizzle ORM
- ✅ Created comprehensive database schema with all required tables:
  - Users (with premium status, usage limits, and activation codes)
  - Subjects, Questions, Quiz Sessions
  - Study Progress, Study Plan Content
  - Competitions, Competition Participants
  - Analytics, Offline Cache, Explained Questions
- ✅ Implemented complete DatabaseStorage class with all CRUD operations
- ✅ Database schema pushed successfully to PostgreSQL via `npm run db:push`
- ✅ All API endpoints now properly connected to PostgreSQL database
- ✅ No TypeScript errors or LSP diagnostics remaining

### Quiz System Completely Fixed and Working
- ✅ **Session Creation Issue Resolved**: Fixed user ID validation in frontend (was sending null)
- ✅ **Database Population**: Added 8 default subjects to database via SQL
- ✅ **ALOC API Integration**: Confirmed working with real JAMB questions
- ✅ **End-to-End Testing**: Complete quiz flow from subject selection to completion verified
- ✅ **Error Handling**: Improved error handling and debugging capabilities

### Premium Activation System Fully Functional
- ✅ WhatsApp-based activation with codes: 0814880, 0901918, 0803989
- ✅ Contact number: +234 814 880 9180 for purchasing activation codes
- ✅ Free users limited to 3 quiz attempts before requiring premium
- ✅ Premium users get unlimited access to all features
- ✅ Activation API endpoint working correctly

### AI Explanation System Verified
- ✅ **Multi-Provider Support**: Google Gemini (primary), OpenAI GPT-4 (fallback)
- ✅ **API Integration**: `/api/quiz/explanation` endpoint operational
- ✅ **Caching System**: Explanations stored in database for performance
- ✅ **Fallback Handling**: Standard explanations when AI services unavailable
- ✅ **Frontend Integration**: AI explanations available in quiz review sections

### Multi-Platform Deployment Ready
- ✅ **Vercel**: `vercel.json` configuration created
- ✅ **Render**: `render.yaml` with PostgreSQL database setup
- ✅ **Netlify**: `netlify.toml` with function routing
- ✅ **Koyeb**: `koyeb.toml` with scaling configuration
- ✅ **Railway**: `railway.toml` deployment configuration
- ✅ **Docker**: Dockerfile for containerized deployment
- ✅ **Environment Variables**: `.env.example` template provided
- ✅ **Deployment Guide**: Comprehensive `DEPLOYMENT.md` documentation

### Technical Architecture Stable
- ✅ PostgreSQL database with complete schema and data
- ✅ All API endpoints tested and working (session creation, questions, explanations, activation)
- ✅ Frontend-backend integration complete
- ✅ ALOC API fetching real examination questions
- ✅ No TypeScript errors or LSP diagnostics
- ✅ Ready for production deployment on multiple platforms